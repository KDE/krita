#!/bin/bash
bash -c "pkg-config --version" > /dev/null 2>&1
